(function($) {
    document.addEventListener('DOMContentLoaded',function(){
		new SmartPhoto(".js-img-viewer",{
		resizeStyle:'fit',
		});
		});
})(jQuery);